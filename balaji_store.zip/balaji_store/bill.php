<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BALAJI STORE</title>
    <!-- For Bootstrap-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    
    <!-- CSS For Print Format -->
    <link rel="stylesheet" media="print" href="invoiceprint.css">
    
    <!-- CSS For Invoice -->
    <link rel="stylesheet"  href="invoice.css">

    <!-- jQuery CDN -->
    <script src="https://code.jquery.com/jquery-3.6.2.slim.js" integrity="sha256-OflJKW8Z8amEUuCaflBZJ4GOg4+JnNh9JdVfoV+6biw=" crossorigin="anonymous"></script>
    
    <!-- For Invoice  -->
    <script src="invoice.js"></script>


</head>
  <body>
    

    <div class="container ">
       

        <div class="card">
            <div class="card-header text-center">
              <h4>NEW BILL</h4>
            </div>
            <div class="card-body">
<form action="save_bill.php" method="POST">
                <div class="row">
                    <div class="col-8">
                        
                    </div>
                </div>


                <table class="table table-bordered text-center">
                    <thead class="table-success">
                      <tr>
                        <th scope="col">S.no.</th>
                        <th scope="col">Product</th>
                        <th scope="col" class="">Qty</th>
                        <th scope="col" class="">Rate</th>
                        <th scope="col" class="">Amount</th>
                        <th scope="col" class="NoPrint">                         
                            <button type="button" class="btn btn-sm btn-success" onclick="BtnAdd()">+</button>
                          
                        </th>

                      </tr>
                    </thead>
                    <tbody id="TBody">
                      <tr id="TRow" class="d-none">
                        <th scope="row">1</th>
                        <td><input type="text" class="form-control" name="product[]" ></td>
                        <td><input type="number"  class="form-control text-end qty" name="qty[]" onchange="Calc(this);"></td>
                        <td><input type="number" class="form-control rate text-end" name="rate[]"  onchange="Calc(this);"></td>
                        <td><input type="number" class="form-control amt text-end" name="amt[]" value="0" readonly=""></td>
                        <td class="NoPrint"><button type="button" class="btn btn-sm btn-danger" onclick="BtnDel(this)">X</button></td>
                      </tr>
                    </tbody>
                  </table>


                  <div class="row">
                    <div class="col-8">
                      
                       <input type="submit" class="btn btn-primary" value="Print" name="" >

                    </div>
                    <div class="col-4">
                        <div class="input-group mb-3">
                            <span class="input-group-text" >Total</span>
                            <input type="number" class="form-control text-end" id="FTotal" name="FTotal" readonly="">
                        </div>
                        <div class="input-group mb-3">
                            <span class="input-group-text" >GST</span>
                            <input type="number" class="form-control text-end" id="FGST" name="FGST" onchange="GetTotal()">
                        </div>
                        <div class="input-group mb-3">
                            <span class="input-group-text" >Net Amt</span>
                            <input type="number" class="form-control text-end" id="FNet" name="FNet" readonly="">
 </form>                       </div>


                    </div>
                </div>
             </div>
          </div>

    </div>

    <center><a href="home.php"><button class="mt-5 btn btn-warning">HOME</button></a></center>


    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </body>
</html>