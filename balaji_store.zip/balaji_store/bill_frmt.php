<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="style.css">
        <title>BALAJI STORE</title>
    </head>
    <body>
        <div class="ticket">
            <img src="./logo.png" alt="Logo">
            <p class="centered">BALAJI STORE
                <br>madurai-11
                <!-- <br>Address line 2</p> -->
            <table>
                <thead>
                    <tr>
                        <th class="sno">S.No</th>
                        <th class="item">Item</th>
                        <th class="rs">Rs</th>
                        <th class="qty">Qty</th>
                        <th class="amt">Amt</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="sno">1</td>
                        <td class="item">ARDUINO UNO R3</td>
                        <td class="rs">150.67</td>
                        <td class="qty">4</td>
                        <td class="amt">600.00</td>
                    </tr>


                   
                </tbody>
            </table>
            <p class="centered">Thanks for your purchase!
                
        </div>
        <button id="btnPrint" class="hidden-print">Print</button>
        <script src="script.js"></script>
    </body>
</html>
<style type="text/css">
	* {
    font-size: 12px;
    font-family: 'Times New Roman';
}

td,
th,
tr,
table {
    border-top: 1px solid black;
    border-collapse: collapse;
}

td.sno,
th.sno {
    width: 105px;
    max-width: 85px;
}

td.quantity,
th.quantity {
    width: 40px;
    max-width: 40px;
/*    word-break: break-all;*/
}

td.price,
th.price {
    width: 40px;
    max-width: 40px;
    word-break: break-all;
}

.centered {
    text-align: center;
    align-content: center;
}

.ticket {
    width: 155px;
    max-width: 155px;
}

img {
    max-width: inherit;
    width: inherit;
    width: 30px;
}

@media print {
    .hidden-print,
    .hidden-print * {
        display: none !important;
    }
}
</style>