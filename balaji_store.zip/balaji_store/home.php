<?php
if ($_SERVER['HTTP_HOST'] == 'localhost') 
{
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "balaji_store_db";
}
else
{
$servername = "sql108.infinityfree.com";
$username = "if0_34353442";
$password = "OIJhUmvASFMGMFP";
$dbname = "if0_34353442_balaji_store_db";
}

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * from bill_tbl";

if ($result = mysqli_query($conn, $sql)) {
    $rowcount = mysqli_num_rows( $result );    
 }

date_default_timezone_set('Asia/Calcutta');
$date = date('Y-m-d');
// echo $date;
$sql2 = "SELECT * from bill_tbl WHERE `created_at`= '$date'";

if ($result = mysqli_query($conn, $sql2)) {
    $rowcount2 = mysqli_num_rows( $result );    
 }

$result = mysqli_query($conn, "SELECT SUM(net_amount) AS value_sum FROM bill_tbl WHERE `created_at`= '$date'"); 
$row = mysqli_fetch_assoc($result); 
$sum = $row['value_sum'];

?><!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js">

  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.0.3/css/font-awesome.css">

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

  <title>BALAJI STORE</title>
</head>
<body>

  <!-- <div class="column">
    <div class="card">
     <img src="home_img.png" width="220">
     <p><h2>BALAJI STORE</h2></p>
    </div>
  </div> -->

  <!-- <div class="column">
    <div class="card home_card">
      <h3>TOTAL BILLS:50</h3>
      <p>TODAY BILL:10</p>
      <p>TODAY SALES:2000</p>
    </div>
  </div> -->

  <div class="container cards">
    
    <div class="row cardss">

  <div class="four col-md-3">
    <div class="counter-box colored">

      <img src="home_img.png" width="220">
     <p><h2>BALAJI STORE</h2></p>

    </div>
  </div>

  <div class="four col-md-2">
    <div class="counter-box">
      <!-- <i class="fa  fa-shopping-cart"></i> -->
      <span class="counter"><?php echo $rowcount; ?></span>
      <p>Total Bill</p>
    </div>
  </div>

  <div class="four col-md-2">
    <div class="counter-box">
      <!-- <i class="fa  fa-shopping-cart"></i> -->
      <span class="counter"><?php echo $rowcount2; ?></span>
      <p>Today Bill</p>
    </div>
  </div>

  <div class="four col-md-2">
    <div class="counter-box">
      <!-- <i class="fa  fa-user"></i> -->
      <span class="counter"><?php echo $sum; ?></span>
      <p>Today Sales</p>
    </div>
  </div>

<div class="col-md-3 frame">
 <a href="bill.php">
  
  <button class="custom-btn btn-5"><span>NEW BILL</span></button>
</div></a>

  </div>  
</div>
<!-- 
  <a href="bill.php">
  <div class="column">
    <div class="card home_card2">
      <h3>NEW BILL</h3>
    </div>
  </div>
</a> -->
  
 

</body>
</html>

<style type="text/css">

.frame {
  width: 90%;
  /*margin: 40px auto;*/
  text-align: center;
}
button {
  margin: 20px;
}
.custom-btn {
  width: 130px;
  height: 40px;
  color: #fff;
  border-radius: 5px;
  padding: 10px 25px;
  font-family: 'Lato', sans-serif;
  font-weight: 500;
  background: transparent;
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
  display: inline-block;
   box-shadow:inset 2px 2px 2px 0px rgba(255,255,255,.5),
   7px 7px 20px 0px rgba(0,0,0,.1),
   4px 4px 5px 0px rgba(0,0,0,.1);
  outline: none;
}
/* 5 */
.btn-5 {
  width: 211px;
  height: 112px;
  font-size: 25px;
  line-height: 42px;
  padding: 0;
  border: none;
  background: rgb(255,27,0);
background: linear-gradient(0deg, rgba(255,27,0,1) 0%, rgba(251,75,2,1) 100%);
}
.btn-5:hover {
  color: #f0094a;
  background: transparent;
   box-shadow:none;
}
.btn-5:before,
.btn-5:after{
  content:'';
  position:absolute;
  top:0;
  right:0;
  height:2px;
  width:0;
  background: #f0094a;
  box-shadow:
   -1px -1px 5px 0px #fff,
   7px 7px 20px 0px #0003,
   4px 4px 5px 0px #0002;
  transition:400ms ease all;
}
.btn-5:after{
  right:inherit;
  top:inherit;
  left:0;
  bottom:0;
}
.btn-5:hover:before,
.btn-5:hover:after{
  width:100%;
  transition:800ms ease all;
}

	body
	{
	background-repeat: no-repeat;
  text-align: center;
  height: 450px;
  background-color: yellow;
}

@import url('https://fonts.googleapis.com/css?family=Autour+One');
h2{
    /*font-family: "Autour One", cursive;*/
    font-weight: bold;
    text-transform: uppercase;
    text-align: center;
    font-size: 35px;
    color: red;
    /*background-color: rgb(84, 84, 84);*/
    /*text-shadow: rgb(0, 0, 0) 2px 2px 2px;*/
}


/* Responsive columns */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 20px;
  }
  .counter-box
  {
    margin-top: 25px;
  }
}

/* Style the counter cards */
.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  padding: 16px;
  text-align: center;
  background-color: #f1f1f1;
}
.home_card
{
	background: rgb(50,219,16);
background: radial-gradient(circle, rgba(50,219,16,1) 0%, rgba(0,232,255,0.4766281512605042) 100%);
}
.home_card2
{
	background: rgb(34,193,195);
background: linear-gradient(0deg, rgba(34,193,195,1) 0%, rgba(253,187,45,1) 100%);

}

.container{
    margin-top:100px;
}

.counter-box {
  display: block;
  background: #f6f6f6;
  padding: 40px 20px 37px;
  text-align: center
}

.counter-box p {
  margin: 5px 0 0;
  padding: 0;
  color: #909090;
  font-size: 18px;
  font-weight: 500
}

.counter-box i {
  font-size: 60px;
  margin: 0 0 15px;
  color: #d2d2d2
}

.counter { 
  display: block;
  font-size: 32px;
  font-weight: 700;
  color: #666;
  line-height: 28px
}

.counter-box.colored {
      background: #FFFF8F;
}

.counter-box.colored p,
.counter-box.colored i,
.counter-box.colored .counter {
  color: #fff
}
</style>

<script>
  
        
        
$(document).ready(function() {

        $('.counter').each(function () {
    $(this).prop('Counter',0).animate({
        Counter: $(this).text()
    }, {
        duration: 4000,
        easing: 'swing',
        step: function (now) {
            $(this).text(Math.ceil(now));
        }
    });
});
 
});  




</script>