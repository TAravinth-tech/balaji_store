<?php

if(isset($_POST['submit']))
{
  $username = $_POST['user'];  
  $password = $_POST['pass'];  
  if($username == "balaji" && $password == "balaji123")
  {
     header('Location: home.php');
  }
  else
  {
     echo "<script>alert('Warning: Wrong Password');</script>";
  }
}


?>
<!DOCTYPE html>
<html>
<head>
	<title>BALAJI STORE</title>
	
	<link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/style.css">
	<script src="https://kit.fontawesome.com/a81368914c.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
	<img class="wave" src="https://w0.peakpx.com/wallpaper/339/608/HD-wallpaper-balaji-lord-thumbnail.jpg">
	<div class="container">
		<div class="img">
			<!-- <img src="https://w0.peakpx.com/wallpaper/339/608/HD-wallpaper-balaji-lord-thumbnail.jpg"> -->
		</div>
		<div class="login-content">
			<form method="POST">
				<img src="home_img.png">
				<h2 class="title">balaji store</h2>
           		<div class="input-div one">
           		   <div class="i">
           		   		<i class="fas fa-user"></i>
           		   </div>
           		   <div class="div">
           		   		<h5>Username</h5>
           		   		<input type="text" name="user" class="input">
           		   </div>
           		</div>
           		<div class="input-div pass">
           		   <div class="i"> 
           		    	<i class="fas fa-lock"></i>
           		   </div>
           		   <div class="div">
           		    	<h5>Password</h5>
           		    	<input type="password" name="pass" class="input">
            	   </div>
            	</div>
            	
            	<input type="submit" class="btn" name="submit" value="Login">
            </form>
        </div>
    </div>
    
</body>
</html>
<script type="text/javascript">
  const inputs = document.querySelectorAll(".input");


function addcl(){
  let parent = this.parentNode.parentNode;
  parent.classList.add("focus");
}

function remcl(){
  let parent = this.parentNode.parentNode;
  if(this.value == ""){
    parent.classList.remove("focus");
  }
}


inputs.forEach(input => {
  input.addEventListener("focus", addcl);
  input.addEventListener("blur", remcl);
});

//Source :- https://github.com/sefyudem/Responsive-Login-Form/blob/master/img/avatar.svg
</script>