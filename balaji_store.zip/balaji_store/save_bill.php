<?php
if ($_SERVER['HTTP_HOST'] == 'localhost') 
{
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "balaji_store_db";
}
else
{
$servername = "sql108.infinityfree.com";
$username = "if0_34353442";
$password = "OIJhUmvASFMGMFP";
$dbname = "if0_34353442_balaji_store_db";
}

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$FTotal = $_POST['FTotal'];
$FGST = $_POST['FGST'];
$FNet = $_POST['FNet'];

$count = count($_POST["product"]);
//echo $count;
$visitorData = count($_POST["product"]);
   
   if ($visitorData > 0) {
       for ($i=1; $i < $visitorData; $i++) { 
      if (trim($_POST['product'] != '')) {
         $product   = $_POST["product"][$i];
         //echo $product;
         $qty  = $_POST["qty"][$i];
         //echo $qty;
         $amt  = $_POST["amt"][$i];
         //echo $amt;
         $rate  = $_POST["rate"][$i];
         //echo $rate;
         $query  = "INSERT INTO bill_tbl (product,quantity,rate,amount,total,gst,net_amount) VALUES ('$product','$qty','$rate','$amt','$FTotal','$FGST','$FNet')";

         $result = mysqli_query($conn, $query);
      }
       }
      // echo "Data inserted successfully";
       // $query  = "INSERT INTO bill_tbl (total,gst,net_amount) VALUES ('$FTotal','$FGST','$FNet')";
       //   $result = mysqli_query($conn, $query);
   }else{
       echo "Please Enter visitor name";
   }

$counts = $i-1;
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <link rel="stylesheet" href="style.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
        <title>BALAJI STORE</title>
    </head>
    <body>
        <div class="ticket"><center>
            <img src="logo.png" class="" alt="Logo">
            </center>
            <p class="centered">BALAJI STORE <br>Madurai-11
                <!-- <br>Address line 2</p> -->
            <table>
                <thead>
                    <tr>
                        <th class="sno">S.No</th>
                        <th class="item">Item</th>
                        <th class="rs">Rs</th>
                        <th class="qty">Qty</th>
                        <th class="amt">Amt</th>
                    </tr>
                </thead>
                <tbody><?php 
//echo $counts;
$sql = "SELECT * FROM `bill_tbl` ORDER BY id DESC LIMIT $counts";
$result = $conn->query($sql);

if ($result->num_rows > 0) 
{
  // output data of each row
  $i=1;
  while($row = $result->fetch_assoc()) 
  {
  ?>
                    <tr class="details">
    <td class=""><?php echo $i; ?></td>
                        <td class=""><?php echo $row["product"]; ?></td>
                        <td class=""><?php echo $row["rate"]; ?></td>
                        <td class=""><?php echo $row["quantity"]; ?></td>
                        <td class=""><?php echo $row["amount"]; ?></td>
                    </tr>
<?php
  $i++;
}
} 
else 
{
  echo "0 results";
}
$conn->close();
?>

                   <tr class="details">
                        <th></th>
                        <th></th>
                        <th></th>
                        <th>GST:</th>
                        <th><?php echo $FGST; ?></th>
                    </tr>
                    <tr>
                        <th ></th>
                        <th ></th>
                        <th ></th>
                        <th >Total:</th>
                        <th ><?php echo $FNet; ?></th>
                    </tr>
                </tbody>
            </table>

            <p class="centered">Thanks for your purchase!

&nbsp;
<a href="bill.php">
  <button class="mt-3 back_button">Back</button>
</a>

        </div>
        <!-- <button id="btnPrint" class="hidden-print">Print</button> -->
        <script src="script.js"></script>
    </body>
</html>
<style type="text/css">
  * {
    font-size: 12px;
    font-family: 'Times New Roman';
}

.details ,thead{
    border-top: 1px solid black;
    border-collapse: collapse;
    text-align: center;
}

.details > td
{
    margin-right: 12px;
}

td.sno,
th.sno {
    width: 40px;
    max-width: 80px;
}

td.item,.rs,.qty,.amt,
th.item,.rs,.qty,.amt {
    width: 40px;
    max-width: 90px;
   
/*    word-break: break-all;*/
}


td.price,
th.price {
    width: 40px;
    max-width: 40px;
    word-break: break-all;
}

.centered {
    text-align: center;
    align-content: center;
}

.ticket {
    margin: 12px;
    width: 155px;
    max-width: 155px;
}

img {
    max-width: inherit;
    width: inherit;
    width: 30px;
}

@media print {
    .back_button,
    .back_button * {
        display: none !important;
    }


    .hidden-print,
    .hidden-print * {
        display: none !important;
    }

    html
    {
       width: 155px;
    max-width: 155px;
    }
}
</style>
<script src="invoice.js">


</script>